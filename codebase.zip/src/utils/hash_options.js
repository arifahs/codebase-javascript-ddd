export default {
  encoding: 'hex',
  folders: {exclude: ['.*', 'node_modules', 'test_coverage']},
  files: {include: ['*.js', '*.json']},
}
