import * as yup from 'yup'

export default {
  name: yup.string().max(100),
}
